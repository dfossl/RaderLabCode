
# Where the python executable is located
pythonInstanceDir = "/usr/local/bin/python3"

# Where the python file is located
pythonModuleDir = "/Users/stephen/Dropbox/•LAB\ DATA/Cm\ Data/C.\ merolae\ Bioinformatics/pipelinepythonscripts/Deseq2EnrichmentWorkFlowFunctions.py"

# Chosen Working Directory (Default is current working directory.)
workingDirectory = getwd()

# Name of the output folder will be appened to current working directory
outputDirName = "R_Output_folder"

# Count file directory
CountFileDirectory = "Au_data.csv"

# AnnotationFileDirectory
AnnotationFileDirectory = "Au_annotation.csv"



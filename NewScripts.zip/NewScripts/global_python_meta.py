
# Directory to the annotations folder.
annotationDir = "/Users/stephen/Dropbox/•LAB DATA/Cm Data/C. merolae Bioinformatics/pipelinepythonscripts/Annotations"


# Dylan -> annotationDir = "Annotations\\Annotations"